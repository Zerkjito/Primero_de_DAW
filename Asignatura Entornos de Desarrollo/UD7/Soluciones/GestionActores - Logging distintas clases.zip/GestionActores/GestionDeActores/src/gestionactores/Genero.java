package gestionactores;

public enum Genero {
    HOMBRE, MUJER
}
