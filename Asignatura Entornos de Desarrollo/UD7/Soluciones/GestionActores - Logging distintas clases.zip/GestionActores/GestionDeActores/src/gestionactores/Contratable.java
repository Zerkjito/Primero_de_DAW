
package gestionactores;

public interface Contratable {
    double calcularSueldo();
}
