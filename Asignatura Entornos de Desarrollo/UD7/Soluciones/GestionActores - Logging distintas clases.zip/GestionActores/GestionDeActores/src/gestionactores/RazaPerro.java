
package gestionactores;

public enum RazaPerro {
    CHIHUAHUA, BOXER, PASTORALEMAN, LABRADOR
}
